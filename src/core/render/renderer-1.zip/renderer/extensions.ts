import { ExtensionSlotName } from '../../extensions/types';
import { createSvgGroup } from './helpers';
import { SvgRendererInternals } from './types';

export function rendererAllocateExtensionSlots(
	state: SvgRendererInternals,
	extensionId: string,
	slots: readonly ExtensionSlotName[]
): Partial<Record<ExtensionSlotName, SVGGElement>> {
	if (!state.svgRoot) {
		throw new Error('SvgRenderer: Cannot allocate extension slots before mount()');
	}

	// Detect duplicate slot names
	const seen = new Set<ExtensionSlotName>();
	for (const slot of slots) {
		if (seen.has(slot)) {
			throw new Error(`Duplicate slot name in allocation: ${slot}`);
		}
		seen.add(slot);
	}

	const result = {} as Partial<Record<ExtensionSlotName, SVGGElement>>;

	for (const slot of slots) {
		const slotRoot = getExtensionSlotRoot(state, slot);
		const child = createSvgGroup(slotRoot, {
			'data-chessboard-id': `extension-${extensionId}-${slot}`,
			'data-extension-id': extensionId
		});
		result[slot] = child;
	}

	state.extensions.allocatedSlots.set(extensionId, result);

	return result;
}

function getExtensionSlotRoot(state: SvgRendererInternals, slot: ExtensionSlotName): SVGGElement {
	switch (slot) {
		case 'underPieces':
			return state.extensions.underPieces;
		case 'overPieces':
			return state.extensions.overPieces;
		case 'dragUnder':
			return state.extensions.dragUnder;
		case 'dragOver':
			return state.extensions.dragOver;
		case 'defs':
			return state.extensions.defs;
		default:
			throw new Error(`Invalid extension slot name: ${slot}`);
	}
}

export function rendererRemoveExtensionSlots(
	state: SvgRendererInternals,
	extensionId: string
): void {
	if (!state.svgRoot) {
		throw new Error('SvgRenderer: Cannot remove extension slots before mount()');
	}

	const slotRoots = [
		state.extensions.underPieces,
		state.extensions.overPieces,
		state.extensions.dragUnder,
		state.extensions.dragOver
	];

	for (const root of slotRoots) {
		const children = Array.from(root.children);
		for (const child of children) {
			if (child.getAttribute('data-extension-id') === extensionId) {
				root.removeChild(child);
			}
		}
	}
}
